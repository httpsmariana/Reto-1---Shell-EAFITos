# EAFITos Shell (V2)

Shell interactiva en C para la materia de Sistemas Operativos.

## Requisitos

- Linux (o WSL en Windows)
- `gcc` con soporte C11
- `make`

## Compilación

Desde la raíz del proyecto:

```bash
make
```

Esto genera el ejecutable `eafitos`.

## Ejecución

```bash
make run
```

o directamente:

```bash
./eafitos
```

Prompt interactivo:

```text
EAFITos>
```

## Comandos del proyecto

### Activos en la versión actual (registrados en `src/commands.c`)

- `calc <num1> <operador> <num2>`: calculadora básica (`+`, `-`, `*`, `/`).
- `limpiar`: limpia la pantalla.
- `usuario`: muestra el usuario actual del sistema.
- `directorio`: muestra el directorio de trabajo actual.
- `copiar <origen> <destino>`: copia un archivo binario o de texto.
- `estadisticas <archivo>`: muestra líneas, palabras y caracteres del archivo.

### Implementados en el proyecto (código existente en `src/`)

Estos comandos también existen en el repositorio y corresponden a la versión base del shell:

- `listar`: lista archivos del directorio actual.
- `leer <archivo>`: imprime el contenido de un archivo.
- `tiempo`: muestra fecha y hora local.
- `crear <archivo>`: crea un archivo vacío.
- `help [comando]`: muestra ayuda general o uso de un comando.
- `history`: muestra historial de comandos.
- `exit`: sale de la shell.

## Ejemplos de uso

```text
EAFITos> calc 10 + 5
EAFITos> usuario
EAFITos> directorio
EAFITos> copiar entrada.txt salida.txt
EAFITos> estadisticas salida.txt
EAFITos> limpiar
```

## Señales de teclado

- `Ctrl+C`: no cierra la shell; interrumpe la línea actual y vuelve al prompt.
- `Ctrl+Z`: no suspende la shell; vuelve al prompt.

## Limpieza

```bash
make clean
```

Elimina el ejecutable generado (`eafitos`).

## Notas

- El parser soporta argumentos separados por espacios y texto entre comillas dobles.
- En esta V2, la tabla activa de comandos está en `src/commands.c`; para habilitar todos los comandos implementados, hay que registrarlos allí.
